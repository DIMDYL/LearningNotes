## 事件监听API

特点：以on开头的就是事件监听对象

## 同步API

以sync结尾的都是同步API

同步API可以通过函数返回值直接获取，如果执行出错会抛出异常

## 异步API

类似于jquery，中的$.ajax() 函数，需要success、fail、complete接收调用结果