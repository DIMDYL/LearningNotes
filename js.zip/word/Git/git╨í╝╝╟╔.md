## 修改Commit信息

``` shell
git commit --amend -m "新的commit信息"
```

