## 创建项目

``` shell
pnpm create vue
```

