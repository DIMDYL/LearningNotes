## vue3脚手架

在vue3中更推荐使用 create-vue 来构建脚手架，create-vue 是技术vint开发的，构建速度更快

如果想要使用 create-vue 必须要使用 node 16.0 或更高的版本

```  npm
npm init vue@latest
```
