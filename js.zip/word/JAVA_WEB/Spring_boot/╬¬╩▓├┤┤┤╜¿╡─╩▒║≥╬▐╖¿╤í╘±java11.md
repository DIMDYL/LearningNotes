### 为什么创建的时候无法选择java11？

idea如果版本高了就会出现在创建Springboot项目时只有Java21和Java17选项

`可以将`https://start.spring.io/` 替换成 `https://start.aliyun.com/阿里云的下载地址