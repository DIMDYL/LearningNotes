var li = document.querySelectorAll(".left ul li")
var box = document.querySelectorAll(".content .right .box")
for(var i = 0; i < li.length; i++){   //遍历li导航栏
    li[i].setAttribute('data-index',i);  //给li导航栏编上号
    li[i].onclick = function(){  //li每一个的点击事件
        for(var i = 0; i < li.length; i++){  //遍历其他都是空
            li[i].setAttribute('class','');
        }
        this.setAttribute('class','boxc');  //自己修改背景色
        var dd = this.getAttribute('data-index');  //获取到当前导航的编号
        console.log(dd);
        for(var i = 0; i < li.length; i++){  //排他遍历其他都隐藏
            box[i].style.display = 'none'
        }
        box[dd].style.display = 'block' //自己显示出来
    }
}